﻿namespace Appshop
{
    partial class FrmClients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TxtDess = new Guna.UI.WinForms.GunaTextBox();
            this.gunaButton2 = new Guna.UI.WinForms.GunaButton();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.TxtName = new Guna.UI.WinForms.GunaTextBox();
            this.TxtSurname = new Guna.UI.WinForms.GunaTextBox();
            this.TxtAddres = new Guna.UI.WinForms.GunaTextBox();
            this.TxtPhone = new Guna.UI.WinForms.GunaTextBox();
            this.TxtCity = new Guna.UI.WinForms.GunaTextBox();
            this.TxtEmail = new Guna.UI.WinForms.GunaTextBox();
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.BtnEditClients = new Guna.UI.WinForms.GunaButton();
            this.TxtCompanyname = new Guna.UI.WinForms.GunaTextBox();
            this.TxtCompanyNo = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(191, 12);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(95, 22);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "Add Clients";
            // 
            // guna2Separator1
            // 
            this.guna2Separator1.Location = new System.Drawing.Point(0, 31);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(501, 19);
            this.guna2Separator1.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.BtnEditClients);
            this.panel1.Controls.Add(this.TxtDess);
            this.panel1.Controls.Add(this.gunaButton2);
            this.panel1.Controls.Add(this.gunaLabel7);
            this.panel1.Controls.Add(this.gunaLabel6);
            this.panel1.Controls.Add(this.gunaLabel4);
            this.panel1.Controls.Add(this.gunaLabel5);
            this.panel1.Controls.Add(this.gunaLabel3);
            this.panel1.Controls.Add(this.gunaLabel9);
            this.panel1.Controls.Add(this.gunaLabel2);
            this.panel1.Controls.Add(this.gunaLabel8);
            this.panel1.Controls.Add(this.gunaLabel1);
            this.panel1.Controls.Add(this.TxtCompanyNo);
            this.panel1.Controls.Add(this.TxtCompanyname);
            this.panel1.Controls.Add(this.TxtName);
            this.panel1.Controls.Add(this.TxtSurname);
            this.panel1.Controls.Add(this.TxtAddres);
            this.panel1.Controls.Add(this.TxtPhone);
            this.panel1.Controls.Add(this.TxtCity);
            this.panel1.Controls.Add(this.TxtEmail);
            this.panel1.Location = new System.Drawing.Point(12, 49);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(470, 362);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // TxtDess
            // 
            this.TxtDess.BaseColor = System.Drawing.Color.White;
            this.TxtDess.BorderColor = System.Drawing.Color.Silver;
            this.TxtDess.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtDess.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtDess.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtDess.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtDess.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtDess.Location = new System.Drawing.Point(39, 268);
            this.TxtDess.Name = "TxtDess";
            this.TxtDess.PasswordChar = '\0';
            this.TxtDess.SelectedText = "";
            this.TxtDess.Size = new System.Drawing.Size(363, 38);
            this.TxtDess.TabIndex = 5;
            // 
            // gunaButton2
            // 
            this.gunaButton2.AnimationHoverSpeed = 0.07F;
            this.gunaButton2.AnimationSpeed = 0.03F;
            this.gunaButton2.BaseColor = System.Drawing.Color.RoyalBlue;
            this.gunaButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaButton2.ForeColor = System.Drawing.Color.White;
            this.gunaButton2.Image = null;
            this.gunaButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton2.Location = new System.Drawing.Point(179, 312);
            this.gunaButton2.Name = "gunaButton2";
            this.gunaButton2.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.gunaButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton2.OnHoverImage = null;
            this.gunaButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton2.Size = new System.Drawing.Size(89, 38);
            this.gunaButton2.TabIndex = 3;
            this.gunaButton2.Text = "Add Clients";
            this.gunaButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaButton2.Click += new System.EventHandler(this.gunaButton2_Click);
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel7.Location = new System.Drawing.Point(36, 250);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(67, 15);
            this.gunaLabel7.TabIndex = 1;
            this.gunaLabel7.Text = "Description";
            this.gunaLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel6.Location = new System.Drawing.Point(239, 186);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(36, 15);
            this.gunaLabel6.TabIndex = 1;
            this.gunaLabel6.Text = "Email";
            this.gunaLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel4.Location = new System.Drawing.Point(239, 124);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(85, 15);
            this.gunaLabel4.TabIndex = 1;
            this.gunaLabel4.Text = "PhoneNumber";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel5.Location = new System.Drawing.Point(36, 186);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(28, 15);
            this.gunaLabel5.TabIndex = 1;
            this.gunaLabel5.Text = "City";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel3.Location = new System.Drawing.Point(36, 124);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(44, 15);
            this.gunaLabel3.TabIndex = 1;
            this.gunaLabel3.Text = "Addres";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel2.Location = new System.Drawing.Point(239, 11);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(54, 15);
            this.gunaLabel2.TabIndex = 1;
            this.gunaLabel2.Text = "Surname";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel1.Location = new System.Drawing.Point(36, 11);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(39, 15);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "Name";
            // 
            // TxtName
            // 
            this.TxtName.BaseColor = System.Drawing.Color.White;
            this.TxtName.BorderColor = System.Drawing.Color.Silver;
            this.TxtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtName.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtName.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtName.Location = new System.Drawing.Point(39, 29);
            this.TxtName.Name = "TxtName";
            this.TxtName.PasswordChar = '\0';
            this.TxtName.SelectedText = "";
            this.TxtName.Size = new System.Drawing.Size(160, 30);
            this.TxtName.TabIndex = 0;
            // 
            // TxtSurname
            // 
            this.TxtSurname.BaseColor = System.Drawing.Color.White;
            this.TxtSurname.BorderColor = System.Drawing.Color.Silver;
            this.TxtSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtSurname.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtSurname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtSurname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtSurname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtSurname.Location = new System.Drawing.Point(242, 29);
            this.TxtSurname.Name = "TxtSurname";
            this.TxtSurname.PasswordChar = '\0';
            this.TxtSurname.SelectedText = "";
            this.TxtSurname.Size = new System.Drawing.Size(160, 30);
            this.TxtSurname.TabIndex = 0;
            // 
            // TxtAddres
            // 
            this.TxtAddres.BaseColor = System.Drawing.Color.White;
            this.TxtAddres.BorderColor = System.Drawing.Color.Silver;
            this.TxtAddres.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtAddres.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtAddres.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtAddres.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtAddres.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtAddres.Location = new System.Drawing.Point(39, 142);
            this.TxtAddres.Name = "TxtAddres";
            this.TxtAddres.PasswordChar = '\0';
            this.TxtAddres.SelectedText = "";
            this.TxtAddres.Size = new System.Drawing.Size(160, 30);
            this.TxtAddres.TabIndex = 0;
            // 
            // TxtPhone
            // 
            this.TxtPhone.BaseColor = System.Drawing.Color.White;
            this.TxtPhone.BorderColor = System.Drawing.Color.Silver;
            this.TxtPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtPhone.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtPhone.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtPhone.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtPhone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtPhone.Location = new System.Drawing.Point(242, 142);
            this.TxtPhone.Name = "TxtPhone";
            this.TxtPhone.PasswordChar = '\0';
            this.TxtPhone.SelectedText = "";
            this.TxtPhone.Size = new System.Drawing.Size(160, 30);
            this.TxtPhone.TabIndex = 0;
            // 
            // TxtCity
            // 
            this.TxtCity.BaseColor = System.Drawing.Color.White;
            this.TxtCity.BorderColor = System.Drawing.Color.Silver;
            this.TxtCity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtCity.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtCity.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtCity.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtCity.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtCity.Location = new System.Drawing.Point(39, 204);
            this.TxtCity.Name = "TxtCity";
            this.TxtCity.PasswordChar = '\0';
            this.TxtCity.SelectedText = "";
            this.TxtCity.Size = new System.Drawing.Size(160, 30);
            this.TxtCity.TabIndex = 0;
            // 
            // TxtEmail
            // 
            this.TxtEmail.BaseColor = System.Drawing.Color.White;
            this.TxtEmail.BorderColor = System.Drawing.Color.Silver;
            this.TxtEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtEmail.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtEmail.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtEmail.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtEmail.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtEmail.Location = new System.Drawing.Point(242, 204);
            this.TxtEmail.Name = "TxtEmail";
            this.TxtEmail.PasswordChar = '\0';
            this.TxtEmail.SelectedText = "";
            this.TxtEmail.Size = new System.Drawing.Size(160, 30);
            this.TxtEmail.TabIndex = 0;
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(447, 1);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(45, 19);
            this.gunaControlBox1.TabIndex = 8;
            this.gunaControlBox1.Click += new System.EventHandler(this.gunaControlBox1_Click);
            // 
            // BtnEditClients
            // 
            this.BtnEditClients.AnimationHoverSpeed = 0.07F;
            this.BtnEditClients.AnimationSpeed = 0.03F;
            this.BtnEditClients.BaseColor = System.Drawing.Color.RoyalBlue;
            this.BtnEditClients.BorderColor = System.Drawing.Color.Black;
            this.BtnEditClients.DialogResult = System.Windows.Forms.DialogResult.None;
            this.BtnEditClients.FocusedColor = System.Drawing.Color.Empty;
            this.BtnEditClients.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnEditClients.ForeColor = System.Drawing.Color.White;
            this.BtnEditClients.Image = null;
            this.BtnEditClients.ImageSize = new System.Drawing.Size(20, 20);
            this.BtnEditClients.Location = new System.Drawing.Point(274, 312);
            this.BtnEditClients.Name = "BtnEditClients";
            this.BtnEditClients.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.BtnEditClients.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BtnEditClients.OnHoverForeColor = System.Drawing.Color.White;
            this.BtnEditClients.OnHoverImage = null;
            this.BtnEditClients.OnPressedColor = System.Drawing.Color.Black;
            this.BtnEditClients.Size = new System.Drawing.Size(89, 38);
            this.BtnEditClients.TabIndex = 6;
            this.BtnEditClients.Text = "Edit";
            this.BtnEditClients.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.BtnEditClients.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // TxtCompanyname
            // 
            this.TxtCompanyname.BaseColor = System.Drawing.Color.White;
            this.TxtCompanyname.BorderColor = System.Drawing.Color.Silver;
            this.TxtCompanyname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtCompanyname.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtCompanyname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtCompanyname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtCompanyname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtCompanyname.Location = new System.Drawing.Point(242, 82);
            this.TxtCompanyname.Name = "TxtCompanyname";
            this.TxtCompanyname.PasswordChar = '\0';
            this.TxtCompanyname.SelectedText = "";
            this.TxtCompanyname.Size = new System.Drawing.Size(160, 30);
            this.TxtCompanyname.TabIndex = 0;
            // 
            // TxtCompanyNo
            // 
            this.TxtCompanyNo.BaseColor = System.Drawing.Color.White;
            this.TxtCompanyNo.BorderColor = System.Drawing.Color.Silver;
            this.TxtCompanyNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtCompanyNo.FocusedBaseColor = System.Drawing.Color.White;
            this.TxtCompanyNo.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.TxtCompanyNo.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TxtCompanyNo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtCompanyNo.Location = new System.Drawing.Point(39, 82);
            this.TxtCompanyNo.Name = "TxtCompanyNo";
            this.TxtCompanyNo.PasswordChar = '\0';
            this.TxtCompanyNo.SelectedText = "";
            this.TxtCompanyNo.Size = new System.Drawing.Size(160, 30);
            this.TxtCompanyNo.TabIndex = 0;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel8.Location = new System.Drawing.Point(36, 64);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(91, 15);
            this.gunaLabel8.TabIndex = 1;
            this.gunaLabel8.Text = "CompanyName";
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel9.Location = new System.Drawing.Point(239, 64);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(103, 15);
            this.gunaLabel9.TabIndex = 1;
            this.gunaLabel9.Text = "CompanyNumber";
            // 
            // FrmClients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(494, 423);
            this.Controls.Add(this.gunaControlBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2Separator1);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmClients";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmClients";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaTextBox TxtName;
        private Guna.UI.WinForms.GunaTextBox TxtSurname;
        private Guna.UI.WinForms.GunaTextBox TxtAddres;
        private Guna.UI.WinForms.GunaTextBox TxtPhone;
        private Guna.UI.WinForms.GunaTextBox TxtCity;
        private Guna.UI.WinForms.GunaTextBox TxtEmail;
        private Guna.UI.WinForms.GunaButton gunaButton2;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
        private Guna.UI.WinForms.GunaTextBox TxtDess;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaButton BtnEditClients;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaTextBox TxtCompanyNo;
        private Guna.UI.WinForms.GunaTextBox TxtCompanyname;
    }
}