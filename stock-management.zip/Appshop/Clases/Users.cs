﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appshop
{
    public class Users
    {
        public static int ID { get; set; }
        public static string sendusername { get; set; } 
        public static string sendPassword { get; set; }


        
        public Users()
        {

        }
    }
}
