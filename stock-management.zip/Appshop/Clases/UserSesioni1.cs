﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appshop
{
    public class UserSesioni1
    {
        public static string CurrentUser = null;
        
    }
}
